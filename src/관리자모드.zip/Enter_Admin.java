import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;

public class Enter_Admin extends JFrame {
	private JTextField textField;
	private JTextField textField_1;

	public Enter_Admin() {
		getContentPane().setBackground(SystemColor.control);

		setBounds(100, 100, 597, 442);
		getContentPane().setLayout(null);
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("재료 종류 추가");
		label.setBounds(12, 10, 104, 15);
		getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("종류 이름");
		lblNewLabel.setBounds(36, 88, 57, 15);
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(118, 85, 116, 21);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("추가");
		btnNewButton.setBounds(36, 147, 97, 23);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("메뉴 종류 추가");
		lblNewLabel_1.setBounds(299, 10, 116, 15);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("메뉴 이름");
		lblNewLabel_2.setBounds(299, 88, 57, 15);
		getContentPane().add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(385, 85, 116, 21);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("추가");
		btnNewButton_1.setBounds(299, 147, 97, 23);
		getContentPane().add(btnNewButton_1);
	}
}
