import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Food_Add extends JFrame{
	private JTextField textField_1;
	private JTextField textField_2;
	public Food_Add() {
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\uC2DD\uB8CC\uD488 \uCD94\uAC00");
		label.setBounds(14, 12, 100, 18);
		getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984");
		lblNewLabel.setBounds(60, 83, 62, 18);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC218\uB7C9");
		lblNewLabel_1.setBounds(60, 113, 62, 18);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uC720\uD1B5\uAE30\uD55C");
		lblNewLabel_2.setBounds(60, 143, 62, 18);
		getContentPane().add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(136, 110, 116, 24);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(136, 140, 116, 24);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\uAD6C\uBD84");
		lblNewLabel_3.setBounds(60, 181, 62, 18);
		getContentPane().add(lblNewLabel_3);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("\uB0C9\uB3D9");
		chckbxNewCheckBox.setBounds(204, 177, 62, 27);
		getContentPane().add(chckbxNewCheckBox);
		
		JCheckBox checkBox = new JCheckBox("\uB0C9\uC7A5");
		checkBox.setBounds(136, 177, 62, 27);
		getContentPane().add(checkBox);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("\uC0C1\uC628");
		chckbxNewCheckBox_1.setBounds(272, 177, 62, 27);
		getContentPane().add(chckbxNewCheckBox_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(136, 80, 116, 24);
		getContentPane().add(comboBox);
		
		JButton btnNewButton = new JButton("\uCDE8\uC18C");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(229, 223, 105, 27);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC644\uB8CC");
		btnNewButton_1.setBounds(110, 223, 105, 27);
		getContentPane().add(btnNewButton_1);
	}
}
