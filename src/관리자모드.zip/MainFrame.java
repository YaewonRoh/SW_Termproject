import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;

public class MainFrame {

	private JFrame frame;
	private JButton btn_Del;
	//public JFrame Food_Add;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(500, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn_Add = new JButton("\uCD94\uAC00");
		btn_Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Food_Add fa = new Food_Add();
				fa.setBounds(100, 100, 365, 320);
				fa.setVisible(true);

			}
		});
		btn_Add.setBounds(398, 38, 105, 27);
		frame.getContentPane().add(btn_Add);
		
		btn_Del = new JButton("\uC0AD\uC81C");
		btn_Del.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Food_Del fd = new Food_Del();
				fd.setBounds(100, 100, 305, 215);
				fd.setVisible(true);
			}
		});
		btn_Del.setBounds(526, 38, 105, 27);
		frame.getContentPane().add(btn_Del);
		
		JButton btn_FoodEnd = new JButton("\uBA54\uB274 \uBCF4\uAE30");
		btn_FoodEnd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				Test t = new Test();
//				t.setBounds(398, 129, 370, 312);
//				frame.getContentPane().add(t);
//				frame.repaint();
			}
		});
		btn_FoodEnd.setBounds(645, 38, 105, 27);
		frame.getContentPane().add(btn_FoodEnd);
		
		JButton btn_Admin = new JButton("관리 모드");
		btn_Admin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Enter_Admin da = new Enter_Admin();
				da.setBounds(100, 100, 400, 280);
				da.setVisible(true);
				
			}
		});
		btn_Admin.setBounds(687, 0, 97, 23);
		frame.getContentPane().add(btn_Admin);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(14, 12, 298, 145);
		frame.getContentPane().add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(14, 169, 298, 145);
		frame.getContentPane().add(panel_2);
		

	}
}
